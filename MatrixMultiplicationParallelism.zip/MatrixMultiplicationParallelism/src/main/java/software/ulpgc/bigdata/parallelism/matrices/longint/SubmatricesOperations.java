package software.ulpgc.bigdata.parallelism.matrices.longint;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class SubmatricesOperations {


    public DenseMatrix multiplySubmatrices(DenseMatrix[] matricesA, DenseMatrix[] matricesB){
        int numberOfRows = (int) Math.sqrt(matricesA.length);
        List<DenseMatrix[]> listResults = new ArrayList<>();
        for(int i = 1; i <= numberOfRows; i++){
            matricesA  = rotateMatricesByRow(matricesA.clone(), i);
            matricesB = rotateMatricesByColumn(matricesB.clone(), i);

            DenseMatrix[] denseMatricesResult = multiplyByThreads(matricesA, matricesB);
            listResults.add(denseMatricesResult);
        }
        DenseMatrix[] resultMatrices = sumSubmatrices(listResults);
        return composeMatrix(resultMatrices);
    }

    private DenseMatrix[] sumSubmatrices(List<DenseMatrix[]> listResults) {
        int numColumns = listResults.get(0).length;
        DenseMatrix[] sumMatrices = new DenseMatrix[numColumns];
        Thread[] threads = new ThreadSum[numColumns];
        MatrixOperations matrixOperations = new MatrixOperations();

        for (int i = 0; i < numColumns; i++) {
            threads[i] = new ThreadSum(listResults, i, matrixOperations);
            threads[i].start();
        }

        for (int i = 0; i < numColumns; i++) {
            try {
                threads[i].join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (threads[i] instanceof ThreadSum) {
                ThreadSum threadSum = (ThreadSum) threads[i];
                sumMatrices[i] = threadSum.getResultMatrix();
            }
        }
        return sumMatrices;
    }

    private DenseMatrix[] multiplyByThreads(DenseMatrix[] matricesA, DenseMatrix[] matricesB){
        int size = matricesA.length;
        DenseMatrix[] denseMatricesResults = new DenseMatrix[size];
        Thread[] threads = new ThreadMultiplication[size];

        for (int i = 0; i < size; i++) {
            threads[i] = new ThreadMultiplication(matricesA[i], matricesB[i]);
            threads[i].start();
        }

        for (int i = 0; i < size; i++) {
            try {
                threads[i].join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            if (threads[i] instanceof ThreadMultiplication) {
                ThreadMultiplication multiThread = (ThreadMultiplication) threads[i];
                DenseMatrix resultMatrix = multiThread.getMatrixResult();
                denseMatricesResults[i] = resultMatrix;
            }
        }
        return denseMatricesResults;
    }


    public DenseMatrix[] rotateMatricesByRow(DenseMatrix[] denseMatrices,  int iteration) {
        int numberOfRows = (int) Math.sqrt(denseMatrices.length);
        for (int i = 0; i < iteration; i++){
            int lastIndexRow = denseMatrices.length-1-(i*numberOfRows);
            int firstIndexRow = denseMatrices.length-1-((i+1)*numberOfRows-1);
            DenseMatrix temp = denseMatrices[firstIndexRow];
            for (int j = firstIndexRow; j < lastIndexRow; j++) {
                denseMatrices[j] = denseMatrices[j + 1];
            }
            denseMatrices[lastIndexRow] = temp;
        }
        return denseMatrices;
    }

    public DenseMatrix[] rotateMatricesByColumn(DenseMatrix[] denseMatrices, int iteration){
        int numberOfRows = (int) Math.sqrt(denseMatrices.length);
        for(int i = 0; i < iteration;i++){
            int lastIndexColumn = denseMatrices.length-1-i;
            int firstIndexColumn = lastIndexColumn-numberOfRows*(numberOfRows-1);
            DenseMatrix temp = denseMatrices[firstIndexColumn];
            for (int j = firstIndexColumn; j < lastIndexColumn; j+=numberOfRows){
                denseMatrices[j] = denseMatrices[j+numberOfRows];
            }
            denseMatrices[lastIndexColumn] = temp;
        }
        return denseMatrices;
    }

    public DenseMatrix composeMatrix(DenseMatrix[] denseMatrices){
        int subMatrixSize = denseMatrices[0].size();
        int numRowsOriginal = (int) Math.sqrt(denseMatrices.length);

        DenseMatrixBuilder denseMatrixBuilder = new DenseMatrixBuilder(numRowsOriginal * subMatrixSize);

        int rowIndex = 0;
        int colIndex = 0;

        for (DenseMatrix matrix : denseMatrices) {
            if (matrix != null) {
                for (int i = 0; i < subMatrixSize; i++) {
                    for (int j = 0; j < subMatrixSize; j++) {
                        denseMatrixBuilder.set(rowIndex * subMatrixSize + i, colIndex * subMatrixSize + j, matrix.get(i, j));
                    }
                }
            }

            colIndex +=1;

            if (colIndex == numRowsOriginal) {
                colIndex = 0;
                rowIndex++;
            }
        }

        return (DenseMatrix) denseMatrixBuilder.get();
    }
}


