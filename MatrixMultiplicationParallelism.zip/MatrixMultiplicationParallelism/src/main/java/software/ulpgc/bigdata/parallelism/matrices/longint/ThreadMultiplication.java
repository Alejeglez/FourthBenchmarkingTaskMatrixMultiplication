package software.ulpgc.bigdata.parallelism.matrices.longint;

public class ThreadMultiplication extends Thread{

    private MatrixOperations matrixOperations;
    private  DenseMatrix matrixA;
    private  DenseMatrix matrixB;

    private  DenseMatrix matrixResult;
    public ThreadMultiplication(DenseMatrix matrixA, DenseMatrix matrixB) {
        this.matrixOperations = new MatrixOperations();
        this.matrixA = matrixA;
        this.matrixB = matrixB;
    }

    public void run(){
        matrixResult =  matrixOperations.multiplyDense(matrixA, matrixB);
    }

    public DenseMatrix getMatrixResult(){
        return matrixResult;
    }
}
