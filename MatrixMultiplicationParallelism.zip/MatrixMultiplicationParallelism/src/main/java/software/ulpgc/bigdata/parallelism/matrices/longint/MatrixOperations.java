package software.ulpgc.bigdata.parallelism.matrices.longint;

public class MatrixOperations {
    public DenseMatrix sumDense(DenseMatrix matrixA, DenseMatrix matrixB){
        DenseMatrixBuilder matrixBuilder = new DenseMatrixBuilder(matrixA.size());
        for(int i = 0; i < matrixA.size(); i++){
            for(int j = 0; j  < matrixA.size(); j++){
                matrixBuilder.set(i,j, matrixA.get(i, j) + matrixB.get(i, j));
            }
        }
        return (DenseMatrix) matrixBuilder.get();
    }

    public DenseMatrix multiplyDense(DenseMatrix matrixA, DenseMatrix  matrixB){
        DenseMatrixBuilder matrixBuilder = new DenseMatrixBuilder(matrixA.size());
        for(int i = 0; i < matrixA.size(); i++){
            for(int j = 0; j < matrixA.size(); j++){
                for (int k = 0; k < matrixA.size(); k++) {
                    matrixBuilder.set(i, j, matrixA.get(i, k) * matrixB.get(k, j));
                }
            }
        }
        return (DenseMatrix) matrixBuilder.get();
    }

    public DenseMatrix[] divideDenseMatrix(DenseMatrix matrix){
        int matrixSize = calculateSmallestSubmatrixSize(matrix.size(), getNumberOfThreads());
        int numberOfMatrices = (matrix.size() / matrixSize) * (matrix.size() / matrixSize);
        int numberOfRows = matrix.size() / matrixSize;
        DenseMatrix[] denseMatrices = new DenseMatrix[numberOfMatrices];
        int matrixNumber = 0;
        for (int i = 0; i < numberOfRows; i++) {
            for (int j = 0; j < numberOfRows; j++) {
                int startRow = i * matrixSize;
                int endRow = startRow + matrixSize;
                int startCol = j * matrixSize;
                int endCol = startCol + matrixSize;

                DenseMatrix subMatrix = (DenseMatrix) extractSubMatrix(matrix, startRow, endRow, startCol, endCol, matrixSize);
                denseMatrices[matrixNumber] = subMatrix;
                matrixNumber += 1;
            }
        }
        return denseMatrices;
    }

    public  Matrix<Long> extractSubMatrix(DenseMatrix matrix, int startRow, int endRow, int startCol, int endCol, int matrixSize) {
        DenseMatrixBuilder  denseMatrixBuilder = new DenseMatrixBuilder(matrixSize);
        int iSub = 0;
        for(int i = startRow; i < endRow; i++){
            int jSub = 0;
            for(int j = startCol; j < endCol; j++){
                denseMatrixBuilder.set(iSub, jSub, matrix.get(i, j));
                jSub += 1;
            }
            iSub +=1;
        }
        return denseMatrixBuilder.get();
    }


    private static int calculateSmallestSubmatrixSize(int size, int numThreads) {
        int smallestSubmatrixSize = 1;
        while (true) {
            if (size % smallestSubmatrixSize == 0){
                int submatricesRow = size / smallestSubmatrixSize;
                int totalSubmatrices = submatricesRow * submatricesRow;
                if (totalSubmatrices <= numThreads) {
                    break;
                }
            }
            smallestSubmatrixSize++;
        }
        return smallestSubmatrixSize;
    }

    private static int getNumberOfThreads() {
        return Runtime.getRuntime().availableProcessors();
    }
}
