package software.ulpgc.bigdata.parallelism.matrices.longint;

import java.util.List;

public class ThreadSum extends Thread {
    private List<DenseMatrix[]> listResults;
    private int columnIndex;
    private MatrixOperations matrixOperations;
    private DenseMatrix resultMatrix;

    public ThreadSum(List<DenseMatrix[]> listResults, int columnIndex, MatrixOperations matrixOperations) {
        this.listResults = listResults;
        this.columnIndex = columnIndex;
        this.matrixOperations = matrixOperations;
    }

    @Override
    public void run() {
        int size = listResults.size();
        DenseMatrix currentMatrix = listResults.get(0)[columnIndex];

        for (int k = 1; k < size; k++) {
            currentMatrix = matrixOperations.sumDense(currentMatrix, listResults.get(k)[columnIndex]);
        }

        resultMatrix = currentMatrix;
    }

    public DenseMatrix getResultMatrix() {
        return resultMatrix;
    }
}