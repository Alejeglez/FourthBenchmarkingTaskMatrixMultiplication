package software.ulpgc.bigdata.parallelism.matrices.longint;

public interface Matrix<T> {
    int size();
    T get(int i, int j);
}

