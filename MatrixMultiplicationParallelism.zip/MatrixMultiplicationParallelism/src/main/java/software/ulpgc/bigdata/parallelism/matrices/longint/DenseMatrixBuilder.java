package software.ulpgc.bigdata.parallelism.matrices.longint;

public class DenseMatrixBuilder implements MatrixBuilder<Long> {

    private final long[][] values;

    public DenseMatrixBuilder(int size) {
        this.values = new long[size][size];
    }

    @Override
    public void set(int i, int j, Long value) {
        values[i][j] += value;
    }

    @Override
    public Matrix<Long> get() {
        return new DenseMatrix(values);
    }


}