package software.ulpgc.bigdata.parallelism.matrices.longint;

public class DenseMatrix implements Matrix<Long> {
    private final long[][] values;

    public DenseMatrix(long[][] values) {
        this.values = values;
    }
    @Override
    public int size() {
        return values.length;
    }

    @Override
    public Long get(int i, int j) {
        return values[i][j];
    }
    public long[][] getValues() {
        return values;
    }
}
