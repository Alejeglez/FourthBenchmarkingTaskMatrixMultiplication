package software.ulpgc.bigdata.parallelism.matrices.longint;

import java.util.stream.IntStream;

public class Streams {
    public DenseMatrix multiplyDense(DenseMatrix matrixA, DenseMatrix matrixB){
        DenseMatrixBuilder matrixBuilder = new DenseMatrixBuilder(matrixA.size());
        IntStream.range(0, matrixA.size()).parallel().forEach(i -> {
                    for (int j = 0; j < matrixA.size(); j++) {
                        for (int k = 0; k < matrixA.size(); k++) {
                            matrixBuilder.set(i, j, matrixA.get(i, k) * matrixB.get(k, j));
                        }
                    }
                }
        );
        return (DenseMatrix) matrixBuilder.get();
    }
}
