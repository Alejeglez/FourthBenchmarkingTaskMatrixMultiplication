package software.ulpgc.bigdata.parallelism.matrices.longint;

public interface MatrixBuilder<T> {
    void set(int i, int j, T value);

    Matrix<T> get();
}