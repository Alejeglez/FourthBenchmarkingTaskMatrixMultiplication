package software.ulpgc.bigdata.parallelism.tests;

import org.junit.BeforeClass;
import org.junit.Test;
import software.ulpgc.bigdata.parallelism.matrices.longint.Streams;
import software.ulpgc.bigdata.parallelism.matrices.longint.SubmatricesOperations;
import software.ulpgc.bigdata.parallelism.matrices.longint.DenseMatrix;
import software.ulpgc.bigdata.parallelism.matrices.longint.MatrixOperations;

import static org.junit.Assert.assertEquals;

public class MatrixMultiplicationTest {

    private static RandomMatrixGenerator randomMatrixGenerator = new RandomMatrixGenerator();
    private static MatrixOperations matrixOperations = new MatrixOperations();
    private static SubmatricesOperations submatricesOperations = new SubmatricesOperations();
    private static Streams streams = new Streams();
    private static DenseMatrix matrixA;
    private static DenseMatrix matrixB;
    private static int size;

    public static void setSize(int newSize) {
        size = newSize;
    }

    @BeforeClass
    public static void setUpMatrixA() {
        matrixA = randomMatrixGenerator.generateDenseMatrix(size);
    }

    @BeforeClass
    public static void setUpMatrixB(){
        matrixB = randomMatrixGenerator.generateDenseMatrix(size);
    }

    private static DenseMatrix[] divideMatrixA(){
        return matrixOperations.divideDenseMatrix(matrixA);
    }

    private static DenseMatrix[] divideMatrixB(){
        return matrixOperations.divideDenseMatrix(matrixB);
    }

    private static DenseMatrix initializeExpectedResultConventional(){
        return  matrixOperations.multiplyDense(matrixA, matrixB);
    }

    @Test
    public static void testMatrixMultiplicationParallelism(){
        DenseMatrix matrix = submatricesOperations.multiplySubmatrices(divideMatrixA(), divideMatrixB());
        assertEquals(initializeExpectedResultConventional().getValues(), matrix.getValues());
        System.out.println("Completed test using threads implementation with size " + matrix.size() + "x" + matrix.size());
        System.out.println("Expected result from dense multiplication without parallelism is equal to the result from the threads implementation!");
    }

    @Test
    public  static  void testMatrixMultiplicationStreams(){
        DenseMatrix matrix = streams.multiplyDense(matrixA, matrixB);
        assertEquals(initializeExpectedResultConventional().getValues(), matrix.getValues());
        System.out.println("Completed test using streams implementation with size " + matrix.size() + "x" + matrix.size());
        System.out.println("Expected result from dense multiplication without parallelism is equal to the result from the streams implementation!");
    }

    public static void main(String[] args) {
        for (int i = 2; i <= 1024; i*=2){
            System.out.println("Initializing test with matrix size of " + i + "x" + i + "...");
            setSize(i);
            setUpMatrixA();
            setUpMatrixB();

            long startTime = System.currentTimeMillis();
            testMatrixMultiplicationParallelism();
            long endTime = System.currentTimeMillis();
            long executionTime = endTime - startTime;

            System.out.println("testMatrixMultiplicationParallelism() executed in " + executionTime + " milliseconds");
            System.out.println();

            startTime = System.currentTimeMillis();
            testMatrixMultiplicationStreams();
            endTime = System.currentTimeMillis();
            executionTime = endTime - startTime;

            System.out.println("testMatrixMultiplicationStreams() executed in " + executionTime + " milliseconds");
            System.out.println();
        }
    }






}
