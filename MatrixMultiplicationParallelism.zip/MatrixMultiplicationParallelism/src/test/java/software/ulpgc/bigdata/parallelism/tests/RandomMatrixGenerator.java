package software.ulpgc.bigdata.parallelism.tests;

import software.ulpgc.bigdata.parallelism.matrices.longint.DenseMatrix;
import software.ulpgc.bigdata.parallelism.matrices.longint.DenseMatrixBuilder;

import java.util.Random;

public class RandomMatrixGenerator {
    public static DenseMatrix generateDenseMatrix(int size) {
        DenseMatrixBuilder denseMatrixBuilder = new DenseMatrixBuilder(size);
        Random random = new Random();
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                Long value = random.nextLong(11);
                denseMatrixBuilder.set(i, j, value);
            }
        }
        return (DenseMatrix) denseMatrixBuilder.get();
    }
}