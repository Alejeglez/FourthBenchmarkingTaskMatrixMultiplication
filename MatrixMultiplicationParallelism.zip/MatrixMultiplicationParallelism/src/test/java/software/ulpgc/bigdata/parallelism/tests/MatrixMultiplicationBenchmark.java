package software.ulpgc.bigdata.parallelism.tests;

import org.openjdk.jmh.annotations.*;
import software.ulpgc.bigdata.parallelism.matrices.longint.Streams;
import software.ulpgc.bigdata.parallelism.matrices.longint.SubmatricesOperations;
import software.ulpgc.bigdata.parallelism.matrices.longint.DenseMatrix;
import software.ulpgc.bigdata.parallelism.matrices.longint.MatrixOperations;

import java.util.concurrent.TimeUnit;

@Fork(value = 4, warmups = 2)
@Warmup(iterations = 5, time = 1, timeUnit = TimeUnit.SECONDS)
@Measurement(iterations = 5, time = 1, timeUnit = TimeUnit.SECONDS)
@BenchmarkMode(Mode.Throughput)
@OutputTimeUnit(TimeUnit.MILLISECONDS)
@State(Scope.Benchmark)

public class MatrixMultiplicationBenchmark {
    @State(Scope.Thread)
    public static class Operands {
        @Param({"2", "4", "8", "16", "32", "64", "128", "256", "512", "1024"})
        // Specify the sizes you want to benchmark
        public int n;

        public DenseMatrix a;
        public DenseMatrix b;

        @Setup
        public void setup() {
            a = RandomMatrixGenerator.generateDenseMatrix(n);
            b = RandomMatrixGenerator.generateDenseMatrix(n);
        }
    }

    @Benchmark
    public void multiplicationConventional(Operands operands) {
        new MatrixOperations().multiplyDense(operands.a, operands.b);
    }

    @Benchmark
    public void multiplicationParallel(Operands operands){
        new SubmatricesOperations().multiplySubmatrices(new MatrixOperations().divideDenseMatrix(operands.a), new MatrixOperations().divideDenseMatrix(operands.b));
    }

    @Benchmark
    public void multiplicationStreams(Operands operands){
        new Streams().multiplyDense(operands.a, operands.b);
    }
}
